// Jack Good
// jg8dp
// Homework 4

public class Song implements Comparable<Song>, Playable{

	private String artist; // the artist performing the song

	private String title; // the title of the song

	private int minutes; // number of min in length

	private int seconds; // number of seconds of the song (always less than 60)

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getMinutes() {
		return minutes;
	}

	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	public int getSeconds() {
		return seconds;
	}

	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}


public Song(String artist, String title) { // constructor for songs
	this.artist = artist;
	this.title =title;
}

public Song(String artist, String title, int minutes, int seconds) { // overloads the Song constructor by using a different method signature
	this.artist = artist;
	this.title = title;
	this.minutes= minutes;
	this.seconds=seconds;
}
public Song(Song s) { // copy constructor for songs
	artist = s.getArtist();
	title = s.getTitle();
	minutes = s.getMinutes();
	seconds = s.getSeconds();
}

@Override
public boolean equals(Object o) { // equals method for the song class
	boolean returnvalue =false;
	if (o instanceof Song) { // check o is instance of song
		Song realsong = (Song) o; // cast object o to song
		if (((this.getArtist().equals(realsong.getArtist())) && (this.getTitle()).equals(realsong.getTitle()))&& (this.getMinutes()==(realsong.getMinutes()))&& (this.getSeconds()==realsong.getSeconds()))
			returnvalue = true; // the above checks that all fields are the same for two song objects and if they are it returns true
	}
	return returnvalue;
	
}

public String toString() { // Use this code for toString EXACTLY

	   return "{Song: title = " + title + " artist = " + artist + "}"; // this code was provided to me 

	}
@Override
public void play() { // Use this code for play EXACTLY

	   System.out.printf("Playing Song: artist = %-20s title = %s\n", artist, title); // this code was provided to me

	}
public int compareTo(Song s) { // compareTo method for the Songs
	int returnvalue =0; // Songs will be ordered by the artist in ascending order. If the artists are the same, then by title in ascending order. If both artist and title are the same, then any order is acceptable.
	if (this.artist.compareTo(s.getArtist())>0) { // first check artist return positive if this.artist is greater than s.artist by using strings compare to method
		returnvalue =1;
	}else if (this.artist.compareTo(s.getArtist())<0) { // return negative if this.artist is less than s.artist by using strings compare to method
		returnvalue =-1;
	}else {
		if(this.title.compareTo(s.getTitle())> 0) { // next check the tiles
			returnvalue = 1; // return positive if this.title is greater than s.title by using strings compare to method
		}else if (this.title.compareTo(s.getTitle())< 0){ // return negative if this.title is less than s.title by using strings compare to method 
			returnvalue =-1;
		}
		else {
			returnvalue =0; // else sort them in any order 
		}
	}
	return returnvalue;
}
@Override
public String getName() { // implementing getName() as prescribed by the Playable Interface
		String songTitle = this.getTitle();
	return songTitle;
}
@Override
public int getPlayTimeSeconds() { // implementing getPlaytimeSeconds() as prescribed by the Playable Interface
		int minutes = this.getMinutes();
		int seconds = this.getSeconds();
		int playTime = minutes*60+seconds; // playtime is minutes multiplied by 60 plus the seconds in a song
	
	return playTime;
}
@Override
public int numberOfSongs() { // implementing the numberOfSongs() as prescribed by the Playable Interface
	return 1; // just one :)
}















}
