// Jack Good
// jg8dp
// Homework 4
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;



public class PlayableJUnitTest {
Song darkFantasy; // initialize Songs and Playlists outside of the SetUp() so tests can access them
Song darkFantasy1;
Song gorgeous;
Song power;
Song allOfTheLights;
Song monster;
PlayList mbdtf;
PlayList foresthillsdrive;
Song norolemodels;
Song hello;
Song apparently;
Song partialConstructorSong;
PlayList loadSongsPlaylist;
Song secSong;
	@Before
	public void setUp() throws Exception {
		darkFantasy = new Song("kanye","darkFantasy",4,38); // construct Songs and Playlists
		darkFantasy1 = new Song("kanye","darkFantasy",4,38);
		gorgeous = new Song("kanye","gorgeous",5,57);
		power = new Song( "Kanye","All of the Lights",4,52);
		allOfTheLights = new Song("kanye","All of the Lights",  5,0);
		monster = new Song("Kanye","Monster",6,18);
		mbdtf= new PlayList("My Beautiful Dark Twisted Fantasy");
		foresthillsdrive = new PlayList("2014 Forest Hills Drive");
		norolemodels = new Song("J. Cole", "No Role Models",4,43);
		hello = new Song("J. Cole", "Hello", 3,39);
		apparently = new Song("J. Cole", "Apparently", 4,53);
		loadSongsPlaylist = new PlayList("Rumors");
		partialConstructorSong = new Song("Artist", "Song");
		secSong = new Song( "","",0, 40);
	}
	
	
	@Test
	public void testSongEqualsBasic() { // testing equals method for song
		assertTrue(hello.equals(hello)); // returns true
		assertFalse(hello.equals(norolemodels)); //returns false
		
	}
	@Test 
	public void testSongEqualsCopy() {
		assertTrue(darkFantasy.equals(darkFantasy1)); // darkfantasy and darkfantasy1 hold different locations in memory but have same contents
		assertFalse(darkFantasy.equals(power)); // returns false
		
	}
	@Test
	public void testToStringFullConstructor() { // tests toString using the full constructor
		assertEquals("{Song: title = darkFantasy artist = kanye}",darkFantasy.toString());
		System.out.println(darkFantasy.toString());
	}
	@Test 
	public void testToStringPartialConstructor() { // test toString using the partial constructor
		assertEquals("{Song: title = Song artist = Artist}",partialConstructorSong.toString());
	}
	@Test
	public void testGetPlayTimeSecondsSongBasic() { // tests getPlayTimeSeconds for the Song Class
		assertEquals(292, power.getPlayTimeSeconds());
		assertEquals(300, allOfTheLights.getPlayTimeSeconds());
	}
	@Test 
	public void testGetPlayTImeSecondsSongZeroMinutes(){ // tests when minutes is zero  
		assertEquals(40, secSong.getPlayTimeSeconds());
	}
	@Test 
	public void testNumberOfSongs() { // full constructor
		assertEquals(1,power.numberOfSongs()); // just 1
	}
	@Test
	public void testNumberOfSongs1() { // partial constructor
		assertEquals(1,partialConstructorSong.numberOfSongs()); // still just 1
	}
	@Test
	public void testToStringPlaylistOnlySongs() { // tests toString method for playlist with only songs
		mbdtf.addSong(allOfTheLights);
		mbdtf.addSong(monster);
		assertEquals("My Beautiful Dark Twisted Fantasy"+"\n"+"{Song: title = All of the Lights artist = kanye}"+"\n"+"{Song: title = Monster artist = Kanye}"+"\n", mbdtf.toString());
	}
	@Test
	public void testToStringPlaylistwithPlaylists() { // tests toString method for playlist with songs and playlists
		mbdtf.addSong(allOfTheLights);
		foresthillsdrive.addSong(monster);
		mbdtf.addPlayList(foresthillsdrive);
		assertEquals("My Beautiful Dark Twisted Fantasy"+"\n"+"{Song: title = All of the Lights artist = kanye}"+"\n"+"2014 Forest Hills Drive"+"\n"+"{Song: title = Monster artist = Kanye}"+"\n"+"\n", mbdtf.toString());
	}
	
	@Test
	public void testLoadSongExample() {
		assertTrue(loadSongsPlaylist.loadSongs("test.txt"));
		assertEquals(loadSongsPlaylist.getPlayable(0), darkFantasy); // check to make sure first index is the first thing in the text file
		
	}
	@Test 
	public void testLoadSongBlank() {
		assertFalse(loadSongsPlaylist.loadSongs("blank.txt")); // blank text file does not work, returns false
		assertEquals(0,loadSongsPlaylist.getPlayTimeSeconds());
	}
	@Test
	public void testAddSongOnce() { // tests adding the song once, should work and return true
		assertTrue(mbdtf.addSong(allOfTheLights));
		assertEquals(mbdtf.toString(),"My Beautiful Dark Twisted Fantasy"+"\n"+"{Song: title = All of the Lights artist = kanye}"+"\n");
	
	}
	@Test
	public void testAddSongTwice() { // tests adding song twice, second try should return false
		mbdtf.addSong(power);
		assertFalse(mbdtf.addSong(power));
	}
	@Test
	public void testClearBoolean() { // tests that clear returns true when it clears the playlist
		mbdtf.addSong(darkFantasy);
		mbdtf.addSong(power);
		assertTrue(mbdtf.clear());
	}
	@Test
	public void testClearFailure() { // tests clear showing mdbtf.addSong(power) returns true because previous occurences of power were cleared
		mbdtf.addSong(darkFantasy);
		mbdtf.addSong(power);
		assertTrue(mbdtf.clear());
		assertTrue(mbdtf.addSong(power));
	}
	@Test
	public void testRemovePlayableIndex1() { // test removePlayable with a song constructed by the partial constructor
		foresthillsdrive.addSong(partialConstructorSong);
		assertEquals(partialConstructorSong, foresthillsdrive.removePlayable(0));
	}
	@Test
	public void testRemovePlayableIndex() { // test removablePlayable with a fully constructed song
		mbdtf.addSong(darkFantasy);
		mbdtf.addSong(power);
		assertEquals(power,mbdtf.removePlayable(1));

	}
	@Test
	public void testRemovePlayableObject() { // tests removing one playable object
		mbdtf.addSong(darkFantasy);
		mbdtf.addSong(power); // adds power once
		assertEquals(power,mbdtf.removePlayable(power));
		assertTrue(mbdtf.addSong(power)); // since power was removed you can add power and have it return true
	}
	@Test
	public void testRemovePlayableObjectMultiple() { // tests removing multiple playable objects
		mbdtf.addSong(darkFantasy);
		mbdtf.addSong(power); //adds power twice
		mbdtf.addSong(power);
		assertEquals(power,mbdtf.removePlayable(power));
		assertTrue(mbdtf.addSong(power)); // since ALL OCCURENCES of power was removed you can add power and have it return true
		
	}
	@Test
	public void testGetPlayableInBounds() { // tests getPlayable with a case in bounds
		mbdtf.addSong(power);
		assertEquals(power,mbdtf.getPlayable(0));
	}
	@Test 
	public void testGetPlayableOutOfBounds() { // tests getPlayable with two cases that are out of bounds, returns null
		mbdtf.addSong(power);
		assertEquals(null,mbdtf.getPlayable(-1));
		assertEquals(null,mbdtf.getPlayable(1));
	}
	@Test
	public void testGetNameSong() { // simple test getName for Song
		assertEquals("darkFantasy",darkFantasy.getName());
	}
	@Test 
	public void testGetNamePlaylist() { // simple test getName Playlist
		assertEquals("My Beautiful Dark Twisted Fantasy", mbdtf.getName());
	}
	
	@Test 
	public void testGetPlayTimeSecondsPlaylistOnlySongs() { // tests getPlayTimeSeconds in a playlist that only contains songs
		mbdtf.addSong(power);
		mbdtf.addSong(allOfTheLights);
		assertEquals(592,mbdtf.getPlayTimeSeconds());
	}
	@Test 
	public void testGetPlayTimeSecondsPlaylistSongsAndPlaylists() { // tests getPlayTimeSeconds in a playlist that contains songs and playlists
		mbdtf.addSong(allOfTheLights);
		foresthillsdrive.addSong(power);
		mbdtf.addPlayList(foresthillsdrive);
		assertEquals(592,mbdtf.getPlayTimeSeconds()); // still works with playlists
	}
	@Test 
	public void testAddPlaylistOnce() { // tests add playlist once, should return true
		assertTrue(mbdtf.addPlayList(foresthillsdrive));
	}
	@Test
	public void testAddPlaylistTwice() { // tests add playlist twice, should return false
		mbdtf.addPlayList(foresthillsdrive);
		assertFalse(mbdtf.addPlayList(foresthillsdrive));
	}

	
	@Test
	public void testSortByNameSongs() { // tests sort by name for songs		
		mbdtf.addSong(norolemodels);
		mbdtf.addSong(power);
		assertTrue(mbdtf.sortByName());
		assertEquals(power,mbdtf.getPlayable(0)); // check index zero is alphabetically first song
		
	}
	@Test
	public void testSortByNamePlaylist() { // sorts by name for playlists
		mbdtf.addSong(monster);
		mbdtf.addSong(darkFantasy);
		foresthillsdrive.addSong(hello);
		mbdtf.addPlayList(foresthillsdrive);
		assertTrue(mbdtf.sortByName()); // check returns true
		assertEquals(foresthillsdrive, mbdtf.getPlayable(0)); // check index zero is alphabetically first playlist
	}
	@Test
	public void testSortByTimeSong() {  // sorts by time for songs
		mbdtf.addSong(norolemodels);
		mbdtf.addSong(power);
		assertTrue(mbdtf.sortByTime());
		assertEquals(norolemodels, mbdtf.getPlayable(0)); // check index zero is shortest song
	}
	
	@Test
	public void testSortByTimePlaylist() { // sorts by time for playlists
		mbdtf.addSong(monster);
		mbdtf.addSong(darkFantasy);
		foresthillsdrive.addSong(hello);
		mbdtf.addPlayList(foresthillsdrive);
		assertTrue(mbdtf.sortByTime());
		assertEquals(foresthillsdrive, mbdtf.getPlayable(0)); // check index zero is shortest playlist
	}
	
	@Test
	public void testNumberOfSongsPlaylistNonZero() { // checks number of songs in a playlist for a nonzero number of songs
		mbdtf.addSong(monster);
		mbdtf.addSong(darkFantasy);
		assertEquals(2,mbdtf.numberOfSongs());
	}
	@Test
	public void testNumberOfSongsPlaylistZero() { // checks number of songs for an empty playlist is zero
		assertEquals(0,mbdtf.numberOfSongs());
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
