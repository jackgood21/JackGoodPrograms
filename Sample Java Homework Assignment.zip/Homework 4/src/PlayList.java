// Jack Good
// jg8dp
// TA helped me with the comparator classes and idea to use instance variables
// Heavy use of StackOverflow throughout
// Homework 4

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class PlayList implements Playable  {
	private String name; // contains the name of the playlist

	private ArrayList<Playable> playableList; // ArrayList of Playable elements that make up the playlist

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Playable> getPlayableList() {
		return playableList;
	}

	public void setPlayableList(ArrayList<Playable> playableList) {
		this.playableList = playableList;
	}

@Override
public String toString() { // toString method for PlayList Class
	String finalString= this.getName()+"\n"; // adding newline
	for (Object o: this.getPlayableList()) { 
		if (o instanceof Song) { // if song cast to song and add to string, if playlist cast to playlist and add to string
			finalString =finalString+((Song)o).toString()+"\n"; // strings are mutable so must add with new line at end
		}else {
			finalString=finalString+((PlayList)o).toString()+"\n";
		}
	}
	return finalString;
}

public PlayList() { // empty playlist named "Untitled"
	name = "Untitled";
	this.playableList = new ArrayList<Playable>();
}
	
public PlayList(String newName) { // PlayList Constructor
	this.name =newName;
	this.playableList = new ArrayList<Playable>();
}

public boolean loadSongs(String fileName) { // loads songs from file
File file = new File(fileName);
boolean returnvalue = false;
try {								// beginning of the try catch 
	Scanner sc = new Scanner(file); // new scanner object
	while(sc.hasNextLine()) {
		returnvalue=true;
		String secondsStr="";
		String rawTitle = sc.nextLine().trim(); // read title from file, strip whitespace from both sides
		String rawArtist =sc.nextLine().trim(); // read artist from file, strip whitespace from both sides
		String rawTime = sc.nextLine().trim(); // read time from file, strip whitespace from both sides
		String deleteline =sc.nextLine(); // burn line
		int colonIndex= rawTime.indexOf(':'); // find index of colon	
		String minutesStr = rawTime.substring(0, colonIndex).trim(); // use index of the colon to get the minutes and strip the whitspace
		int minutes= Integer.parseInt(minutesStr); // cast to int
		secondsStr = rawTime.substring(colonIndex+1,rawTime.length()).trim(); // use index of the colon to get the seconds and strip the whitespace
		int seconds = Integer.parseInt(secondsStr); // cast to int
		while (seconds>59) { // check that the seconds are not greater than 59
			seconds =seconds-60; // while they are subtract 60 seconds and add one minute to minutes
			minutes =minutes+1; 
		}
		Song s = new Song(rawArtist,rawTitle,minutes,seconds); // create a new song object 
		playableList.add(s); // add the new song to the playableList
		}

} catch (FileNotFoundException e) { // if no file found catch it and print out error and set returnvalue = false
	returnvalue = false;
	e.printStackTrace();
}
	return returnvalue;
}
public boolean clear() {// removes all playable elements in the playlist
this.playableList.clear(); // uses arraylist method clear()... found this on StackOverflow
return true;
}

public boolean addSong(Song s) { // adds Song s to the end of the play list
boolean returnvalue = false;
if (!(playableList.contains(s))) { // if playableList doesnt contain the song, then add it and set returnvalue to true
	playableList.add(s);
	returnvalue =true;
}
return returnvalue;
}
	
public Playable removePlayable(int index) { // removes Playable element at index from the list and returns it
ArrayList<Playable> playlist = this.getPlayableList(); // create new Playable object from the playable list
Playable returnvalue = playlist.remove(index); // remove playable object at the index
return returnvalue;
}

public Playable removePlayable(Playable p) { // removes every occurrence of Playable p from the list and returns p
ArrayList<Playable> playlist = this.getPlayableList(); // create new Playable object from the playable list
while(playlist.remove(p)) { // found this syntax on stack overflow, while there was a previous object to remove keep removing
}
return p;
}



public Playable getPlayable(int index) { // returns the Playable element at the appropriate index
ArrayList<Playable> playableList = this.getPlayableList(); // create new Playable object from the playable list
Playable returnvalue= null; // if index is out of range return null
if ((index>=0)&& (index< playableList.size()) ) { // check index is valid based on the range
returnvalue =playableList.get(index); // get from array list at index
}
return returnvalue;
}

public boolean addPlayList(PlayList pl) { //adds the PlayList that is being passed to the end of the playableList and returns true unless the playableList already contains a playlist with the same name
	boolean returnvalue = false;
	if (!(playableList.contains(pl))) { // if playableList doesnt contain the playlist, then add it and set returnvalue to true
		playableList.add(pl); // add the playlist
		returnvalue =true;
	}
	return returnvalue;
}
	
@Override
public void play() { // implements play() on each song in the playlist
	for (Object o: playableList) { 
		if (o instanceof Song) { // // if song cast to song and play it, if playlist cast to playlist and play it
			Song s = (Song)o;
			s.play();
		}else {
			for (Playable song: ((PlayList)o).getPlayableList()){ // must iterate through it if playlist
				song.play();
			}
		}
	
	}
}
public boolean sortByName() {
	Collections.sort(this.playableList, new SortByName()); // use collections.sort to sort the playable list by name by using an instance of the SortByName class
	return true;
	
}
public boolean sortByTime() {
	Collections.sort(this.playableList, new SortByTime()); // use collections.sort to sort the playable list by name by using an instance of the SortByTime class
	return true;
}

@Override
public int getPlayTimeSeconds() { // gets playtime of the whole playlist, uses similar logic to play()
	int playTime =0;
	for (Object o: this.getPlayableList()) { // if song cast to song and get its play time and add it to playtime, if playlist cast to playlist and get its play time and add it to play time
		if (o instanceof Song) {
			playTime = playTime + ((Song)(o)).getPlayTimeSeconds();
		}else {
			for (Playable s: ((PlayList)o).getPlayableList()){ // must iterate through it if playlist
				playTime= playTime+ s.getPlayTimeSeconds();
			}
		}
	}
	return playTime;
}

@Override
public int numberOfSongs() { // returns the number of songs in the playlist
	int songNumber =0;
	for (Object o: getPlayableList()) { // for each object in the playlist
		if (o instanceof Song) { // if instance of song add one to the song number
			songNumber = songNumber + 1;
		}else {  // since its an instance of playlist, must iterate through it
			for (Playable s: ((PlayList)o).getPlayableList()){ // add one to the song number for each item in the playlist
				songNumber = songNumber+1;
			}
		}
	}
	return songNumber;
}


	
}

class SortByName implements Comparator<Playable>{ // A TA showed by how to do this, makes a class SortByName so you can use instances of it in collections.sort
	public int compare( Playable a, Playable b) { // compares two playable objects
		return a.getName().compareTo(b.getName()); // use string compareTo method to compare the names of a and b
	}
}

class SortByTime implements Comparator<Playable>{  // A TA showed by how to do this, makes a class SortByTime so you can use instances of it in collections.sort
	public int compare(Playable a, Playable b) { // compares two playable objects
		return a.getPlayTimeSeconds()-b.getPlayTimeSeconds(); // just subtract playtime b from playtime a and return it... negative if b is bigger, postive if a is bigger, zero if equal
	}
}




